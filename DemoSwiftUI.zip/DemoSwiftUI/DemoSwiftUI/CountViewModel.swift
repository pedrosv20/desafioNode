import Foundation
import Combine

struct CountModel {
    var count: Int = 3 {
        didSet {
            if count < 0 {
                count = 0
            }
        }
    }
    
    var triviaText: String?
}


public class CountViewModel: ObservableObject {
    // MARK: - Properties
    
    @Published var model: CountModel = .init()
    
    // MARK: - Public API
    func getTrivia() async throws {
        do {
            let string = try await getNumberTrivia()
            await updateModel(text: string)
        }
        
    }
    
    func getNumberTrivia() async throws -> String {
        guard let url = URL(string: "http://numbersapi.com/\(String(model.count))") else {
            throw NSError.init(domain: "0", code: 1)
        }

        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            let response = try JSONDecoder().decode(String.self, from: data)
            return response
        }
    }
    
    @MainActor
    fileprivate func updateModel(text: String) async {
        model.triviaText = text
    }
}

public final class CountViewModelFake: CountViewModel {
    public override func getTrivia() async throws {
            let text = ["0 is the number of times that Palmeiras has won the Club World Cup in football",
                        "1 is the number of moons orbiting Earth.",
                        "2 is the first magic number in physics.",
                        "3 is the number of words or phrases in a Tripartite motto"
            ]
            let trivia = text[model.count]

            await updateModel(text: trivia)
    }
}


public final class CountViewModelMock: CountViewModel {
    public private(set) var triviaTextToBeReturned: String
    public private(set) var getNumberTriviaShouldThrowError: Bool
    
    init(triviaTextToBeReturned: String, getNumberTriviaShouldThrowError: Bool = false) {
        self.triviaTextToBeReturned = triviaTextToBeReturned
        self.getNumberTriviaShouldThrowError = getNumberTriviaShouldThrowError
    }
    
    override func getTrivia() async throws {
        let triviaText = try await getNumberTrivia()
        await updateModel(text: triviaText)
    }
    
    override func getNumberTrivia() async throws -> String {
        if getNumberTriviaShouldThrowError {
            throw NSError.init(domain: "APIError", code: 1)
        }
        try? await Task.sleep(for: .seconds(3))
        return triviaTextToBeReturned
    }
    
    @MainActor
    override fileprivate func updateModel(text: String) async {
        model.triviaText = text
    }
}













/*
 
 let text = [
     "ola tudo bem",
     "esse numero é top",
     "ahahaha",
     "ola \(count) tudo bem", "esse \(count) é top", "heheheh"].randomElement()
 
 DispatchQueue.main.async { [weak self] in
     self?.triviaText = text ?? ""
 }
 
 
 
 */
