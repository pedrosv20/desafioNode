//
//  DemoSwiftUIApp.swift
//  DemoSwiftUI
//
//  Created by Pedro Silva Vargas on 10/07/23.
//

import SwiftUI

@main
struct DemoSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            
        }
    }
}
