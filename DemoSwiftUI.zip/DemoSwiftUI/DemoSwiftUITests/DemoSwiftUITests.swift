//
//  DemoSwiftUITests.swift
//  DemoSwiftUITests
//
//  Created by Pedro Silva Vargas on 10/07/23.
//
@testable import DemoSwiftUI
import XCTest

final class DemoSwiftUITests: XCTestCase {
    func test_requestTrivia_shouldReturnTriviaText() async {
        // Given
        let expectedString = "3 is the number of spatial dimensions we perceive our universe to have."
        let sut = CountViewModelMock(triviaTextToBeReturned: expectedString)
        
        // When
        try? await sut.getTrivia()
        
        // Then
        XCTAssertNotNil(sut.model.triviaText)
        XCTAssertEqual(sut.model.triviaText, expectedString)
    }
    
    func test_requestTrivia_shouldHandleError() async {
        // Given
        let sut = CountViewModelMock(triviaTextToBeReturned: "", getNumberTriviaShouldThrowError: true)

        do {
            // When
            try await sut.getTrivia()
            XCTFail("code should throw error")
        } catch {
            // Then
            XCTAssertNil(sut.model.triviaText)
        }
    }
}


// teste throw
