import SwiftUI
import ComposableArchitecture

struct ComposableArchitectureContentView: View {
    
    var state: Store
    
    var body: some View {
        ZStack {
            Color.green
                .edgesIgnoringSafeArea(.all)
            VStack {
                Text("Count Menu")
                    .frame(width: 100, height: 30)
                    .roundedRectangleBackground(color: .blue, cornerRadius: 4)
                    
                CountView()
                    .roundedRectangleBackground(color: .white, cornerRadius: 8)
                    .padding(.horizontal, 12)
            }
        }
    }
    
    @ViewBuilder
    func roundedRectangleView(_ color: Color, _ radius: CGFloat) -> some View {
        RoundedRectangle(cornerRadius: radius)
            .foregroundColor(color)
    }
}


struct CountView: View {
    @StateObject var viewModel: CountViewModelFake = .init()
    
    var body: some View {
        VStack {
            triviaView
            
            countView

            Stepper("", value: $viewModel.model.count, step: 1) { editingChanged in
                if !editingChanged {
                    Task {
                        do {
                            try? await viewModel.getTrivia()
                        }
                    }
                }
            }
            .labelsHidden()
        }
        .task {
            do {
                try? await viewModel.getTrivia()
            }
        }
        .padding()
    }
    
    @ViewBuilder
    var triviaView: some View {
        Text(viewModel.model.triviaText != nil ? viewModel.model.triviaText! : "TriviaText will be shown here")
            .font(.callout)
            .if(viewModel.model.triviaText != nil) {
                $0.foregroundColor(.blue)
                    .bold()
            } elseTransform: {
                $0.foregroundColor(.red)
            }
    }
    
    var countView: some View {
        Text(String(viewModel.model.count))
            .font(.largeTitle)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct RoundedRectangleBackground: ViewModifier {
    let color: Color
    let radius: CGFloat
    
    func body(content: Content) -> some View {
        content.background {
            RoundedRectangle(cornerRadius: radius)
                .foregroundColor(color)
        }
    }
}

extension View {
    func roundedRectangleBackground(color: Color, cornerRadius: CGFloat) -> some View {
        modifier(RoundedRectangleBackground(color: color, radius: cornerRadius))
    }
}

public extension View {
    @ViewBuilder
    func `if`<Content: View>(_ condition: Bool, transform: ((Self) -> Content)) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
    
    @ViewBuilder
    func `if`<IFContent: View, ElseContent: View>(
        _ condition: Bool,
        transform: ((Self) -> IFContent),
        elseTransform: ((Self) -> ElseContent)
    ) -> some View {
        if condition {
            transform(self)
        } else {
            elseTransform(self)
        }
    }
}

